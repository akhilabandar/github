package com.example.movierecommendationapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.movierecommendationapp.screens.HomeScreen
import com.example.movierecommendationapp.screens.MovieDetailScreen
import com.example.movierecommendationapp.screens.SearchScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            AppNavigation()
        }
    }
}


@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "home_screen") {
        // Home Screen
        composable("home_screen") {
            HomeScreen(navController)
        }


        composable("search_screen") {
            SearchScreen(navController)
        }

        composable(
            route = "movie_detail_screen/{movieId}",
            arguments = listOf(navArgument("movieId") { type = NavType.IntType })
        ) { backStackEntry ->
            val movieId = backStackEntry.arguments?.getInt("movieId") ?: -1
            if (movieId > 0) {
                MovieDetailScreen(movieId = movieId)
            } else {

            }
        }
    }
}