package com.example.movierecommendationapp.api_Data

data class Medium(
    val height: Int,
    val url: String,
    val width: Int
)