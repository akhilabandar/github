package com.example.movierecommendationapp.api_Data

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

const val TMDB_API_KEY = "9a9d1179912f77033b9e5f8c40292c85"
const val BASE_URL = "https://api.themoviedb.org/3/"

interface TMDbApi {
    @GET("trending/movie/day")
    suspend fun getTrendingMovies(
        @Query("api_key") apiKey: String = TMDB_API_KEY
    ): API

    @GET("search/movie")
    suspend fun searchMovies(
        @Query("api_key") apiKey: String = TMDB_API_KEY,
        @Query("query") query: String
    ): API

    @GET("movie/{movieId}")
    suspend fun getMovieDetails(
        @Path("movieId") movieId: Int,
        @Query("api_key") apiKey: String = TMDB_API_KEY
    ): MovieDetail

    @GET("movie/{movieId}/videos")
    suspend fun getMovieTrailers(
        @Path("movieId") movieId: Int,
        @Query("api_key") apiKey: String = TMDB_API_KEY
    ): YT_API
}

object ApiClient {
    val retrofit: TMDbApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(TMDbApi::class.java)
    }
}