package com.example.movierecommendationapp.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import com.example.movierecommendationapp.api_Data.ApiClient
import com.example.movierecommendationapp.api_Data.MovieDetail
import kotlinx.coroutines.launch

@Composable
fun MovieDetailScreen(movieId: Int) {
    val api = ApiClient.retrofit
    var movieDetail by remember { mutableStateOf<MovieDetail?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(movieId) {
        coroutineScope.launch {
            try {
                movieDetail = api.getMovieDetails(movieId = movieId)
                errorMessage = null
            } catch (e: Exception) {
                errorMessage = "Failed to load movie details. Please try again."
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        when {
            errorMessage != null -> {
                Text(
                    text = errorMessage!!,
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(16.dp)
                )
            }
            movieDetail == null -> {
                Text("Loading...", style = MaterialTheme.typography.bodyLarge)
            }
            else -> {
                MovieDetailContent(movieDetail!!)
            }
        }
    }
}

@Composable
fun MovieDetailContent(movieDetail: MovieDetail) {
    LazyColumn(modifier = Modifier.padding(16.dp)) {
        item {
            // Movie poster
            Image(
                painter = rememberAsyncImagePainter("https://image.tmdb.org/t/p/w500/${movieDetail.poster_path}"),
                contentDescription = movieDetail.title,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Movie title
            Text(
                text = movieDetail.title,
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Release date
            Text(
                text = "Release Date: ${movieDetail.release_date}",
                style = MaterialTheme.typography.bodyLarge
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Rating
            Text(
                text = "Rating: ${movieDetail.vote_average}/10",
                style = MaterialTheme.typography.bodyLarge
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Genres
            Text(
                text = "Genres: ${movieDetail.genres.joinToString { it.name }}",
                style = MaterialTheme.typography.bodyLarge
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Overview
            Text(
                text = movieDetail.overview,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}