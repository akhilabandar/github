package com.example.movierecommendationapp.api_Data

data class Id(
    val kind: String,
    val videoId: String
)