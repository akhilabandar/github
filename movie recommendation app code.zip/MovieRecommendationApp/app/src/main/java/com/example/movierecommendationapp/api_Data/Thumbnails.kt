package com.example.movierecommendationapp.api_Data

data class Thumbnails(
    val default: Default,
    val high: High,
    val medium: Medium
)