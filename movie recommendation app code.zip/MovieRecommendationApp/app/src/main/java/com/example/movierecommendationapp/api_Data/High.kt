package com.example.movierecommendationapp.api_Data

data class High(
    val height: Int,
    val url: String,
    val width: Int
)