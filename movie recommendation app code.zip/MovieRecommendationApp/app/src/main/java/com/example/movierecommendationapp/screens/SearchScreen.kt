package com.example.movierecommendationapp.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.TextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.movierecommendationapp.api_Data.ApiClient
import com.example.movierecommendationapp.api_Data.Result
import kotlinx.coroutines.launch

@Composable
fun SearchScreen(navController: NavController) {
    val api = ApiClient.retrofit
    var movies by remember { mutableStateOf<List<Result>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()

    Column(Modifier.padding(16.dp)) {
        TextField(
            value = query,
            onValueChange = {
                query = it
                if (query.isNotEmpty()) {
                    coroutineScope.launch {
                        try {
                            val response = api.searchMovies(query = query)
                            movies = response.results
                        } catch (e: Exception) {
                            movies = emptyList()
                        }
                    }
                }
            },
            label = { Text("Search Movies") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn {
            items(movies) { movie ->
                MovieItem(movie = movie, navController = navController)
            }
        }
    }
}