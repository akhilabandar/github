package com.example.movierecommendationapp.api_Data

data class PageInfo(
    val resultsPerPage: Int,
    val totalResults: Int
)