package com.example.movierecommendationapp.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.movierecommendationapp.api_Data.ApiClient
import com.example.movierecommendationapp.api_Data.Result
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(navController: NavController) {
    val api = ApiClient.retrofit
    var movies by remember { mutableStateOf<List<Result>>(emptyList()) }
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        coroutineScope.launch {
            val response = api.getTrendingMovies()
            movies = response.results
        }
    }

    Column(Modifier.padding(16.dp)) {
        Button(
            onClick = { navController.navigate("search_screen") },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Search Movies")
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn {
            items(movies) { movie ->
                MovieItem(movie = movie, navController = navController)
            }
        }
    }
}